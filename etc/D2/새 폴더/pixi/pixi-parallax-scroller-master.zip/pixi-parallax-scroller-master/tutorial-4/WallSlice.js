function WallSlice(type, y) {
	this.type   = type;
	this.y      = y;
	this.sprite = null;
}

WallSlice.WIDTH = 64;