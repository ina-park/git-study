Pixi.js Parallax Scroller Tutorial: Part 4/4
================================

This is the accompanying source code for part 4 of *[Pixi.js Parallax Scroller Tutorial](http://www.yeahbutisitflash.com/?p=6938)* by *[Christopher Caleb](http://www.yeahbutisitflash.com/?page_id=2)*.

Artwork by *[Marcus Gray](http://gray-marcus.wix.com/grayillustration)*.
