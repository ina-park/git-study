Pixi.js Parallax Scroller Tutorial: Part 3
================================

This is the accompanying source code for part 3 of *[Pixi.js Parallax Scroller Tutorial](http://www.yeahbutisitflash.com/?p=6496)* by *[Christopher Caleb](http://www.yeahbutisitflash.com/?page_id=2)*.

Artwork by *[Marcus Gray](http://gray-marcus.wix.com/grayillustration)*.
