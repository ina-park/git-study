Pixi.js Parallax Scroller Tutorial: Part 2
================================

This is the accompanying source code for part 2 of *[Pixi.js Parallax Scroller Tutorial](http://www.yeahbutisitflash.com/?p=5666)* by *[Christopher Caleb](http://www.yeahbutisitflash.com/?page_id=2)*.

Artwork by *[Marcus Gray](http://gray-marcus.wix.com/grayillustration)*.